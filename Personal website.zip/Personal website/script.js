// You can add JavaScript functionality here if needed
document.getElementById("contact-form").addEventListener("submit", function(event) {
    event.preventDefault();
    // Add your form submission logic here
    alert("Form submitted!");
});
